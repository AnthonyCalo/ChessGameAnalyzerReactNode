// Opening book for Wukong JS
const book = [
  'b2b3 d7d5 c1b2 c7c5 e2e3 b8c6 f2f4 g8f6 g1f3 c8f5 f1b5 e7e6 f3e5 d8c7 e1g1 f8e7 b1c3 e8g8',
  'd2d4 b8c6 e2e4 e7e5 d4d5 c6e7 c2c4 e7g6 b1c3 g8f6 f1d3 f8c5 g1f3 d7d6 e1g1 c8g4 h2h3',
  'e2e4 c7c5 b1c3 d7d6 f2f4 g7g6 g1f3 f8g7 g2g3 b8c6 f1g2 e7e6 d2d3 g8e7 e1g1 e8g8',
  'e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g7g6 b1c3 f8g7 f2f3 g8f6 c1e3 e8g8 d1d2 b8c6 f1c4 c8d7 c4b3 a8b8 e1c1',
  'e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7 f1e1 b7b5 a4b3 e8g8 c2c3 d7d5',
  'g2g3 b8c6 f1g2 e7e5 c2c4 g8f6 b1c3 f8c5 e2e3 a7a6 g1e2 c5a7 a2a3 d7d6 h2h3 h7h5 d2d4 e5d4 e3d4 c8f5 c1e3 e8g8 e1g1 d8d7',
  'd2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 e7e6 e2e3 b8d7 d1c2 f8d6 f1d3 e8g8 e1g1',
  'c2c4 e7e6 g2g3 d7d5 g1f3 g8f6 d2d4 d5c4 f1g2 a7a6 e1g1 b8c6 e2e3 c8d7 b1c3 f8e7'
]
